#!/usr/bin/env python3
"""
Sync dataset after manual validation.

Removes images + labels from the curated dataset for any crop
that was deleted from data/ball_crops_validation/.

Run AFTER you've deleted bad crops from the validation folder.
"""

from pathlib import Path

DATASET_DIR = Path("data/curated_dataset")
VALIDATION_DIR = Path("data/ball_crops_validation")
SPLITS = ["train", "val"]


def main():
    if not VALIDATION_DIR.exists():
        print(f"[ERROR] {VALIDATION_DIR} not found. Run prepare_validation_crops.py first.")
        return

    # Build set of filenames that survived validation
    surviving = {p.name for p in VALIDATION_DIR.glob("*.jpg")}
    print(f"Surviving crops in validation folder: {len(surviving)}")

    removed_images = 0
    removed_labels = 0
    missing_labels = 0

    for split in SPLITS:
        images_dir = DATASET_DIR / split / "images"
        labels_dir = DATASET_DIR / split / "labels"

        if not images_dir.exists():
            continue

        for img_path in sorted(images_dir.glob("*.jpg")):
            if img_path.name not in surviving:
                # Remove image
                img_path.unlink()
                removed_images += 1

                # Remove corresponding label
                label_path = labels_dir / (img_path.stem + ".txt")
                if label_path.exists():
                    label_path.unlink()
                    removed_labels += 1
                else:
                    missing_labels += 1

    print(f"\nRemoved: {removed_images} images, {removed_labels} labels")
    if missing_labels:
        print(f"  (labels missing for {missing_labels} images — already clean)")

    remaining = sum(
        len(list((DATASET_DIR / s / "images").glob("*.jpg")))
        for s in SPLITS
        if (DATASET_DIR / s / "images").exists()
    )
    print(f"Remaining in dataset: {remaining} images")
    print("\nDone. You can now restart YOLO training on the cleaned dataset.")


if __name__ == "__main__":
    main()

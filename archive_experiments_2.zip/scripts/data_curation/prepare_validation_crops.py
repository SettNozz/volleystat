#!/usr/bin/env python3
"""
Prepare upscaled crops for manual validation.

Creates data/ball_crops_validation/ with 128x128 upscaled images from
the full curated dataset (train + val splits).

After you manually delete bad crops from that folder, run:
    python scripts/data_curation/sync_after_validation.py
to remove the corresponding images+labels from the dataset.
"""

import cv2
import numpy as np
from pathlib import Path
import shutil

DATASET_DIR = Path("data/curated_dataset")
OUTPUT_DIR = Path("data/ball_crops_validation")
UPSCALE_SIZE = 128  # px — visible in Windows Explorer thumbnail view

SPLITS = ["train", "val"]


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    copied = 0
    skipped = 0

    for split in SPLITS:
        images_dir = DATASET_DIR / split / "images"
        if not images_dir.exists():
            print(f"[WARN] {images_dir} not found, skipping")
            continue

        for img_path in sorted(images_dir.glob("*.jpg")):
            img = cv2.imread(str(img_path))
            if img is None:
                print(f"[WARN] Cannot read {img_path.name}")
                skipped += 1
                continue

            # Upscale with nearest-neighbor to keep the pixel art look,
            # then apply mild sharpening for better visibility
            upscaled = cv2.resize(img, (UPSCALE_SIZE, UPSCALE_SIZE),
                                  interpolation=cv2.INTER_NEAREST)

            # Add thin border so individual crops are clearly separated
            bordered = cv2.copyMakeBorder(
                upscaled, 2, 2, 2, 2,
                cv2.BORDER_CONSTANT, value=(200, 200, 200)
            )

            out_path = OUTPUT_DIR / img_path.name
            cv2.imwrite(str(out_path), bordered)
            copied += 1

    print(f"\nDone! {copied} crops copied to {OUTPUT_DIR}/")
    print(f"Skipped: {skipped}")
    print(f"\nNext steps:")
    print(f"  1. Open {OUTPUT_DIR.resolve()} in Windows Explorer")
    print(f"  2. Switch to 'Large icons' view (Ctrl+Shift+2 in Explorer)")
    print(f"  3. Delete any images that are NOT a volleyball")
    print(f"  4. Run:  python scripts/data_curation/sync_after_validation.py")


if __name__ == "__main__":
    main()

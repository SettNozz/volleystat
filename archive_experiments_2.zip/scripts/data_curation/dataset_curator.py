#!/usr/bin/env python3
"""
Dataset Curator - FastAPI app for curating volleyball ball dataset
"""

import json
import shutil
import uuid
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
import cv2
import numpy as np
from datetime import datetime
import base64
from io import BytesIO
from PIL import Image, ImageDraw

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel


class CurationDecision(BaseModel):
    """Model for curation decision."""
    action: str  # 'accept' or 'skip'
    image_id: str


class DatasetCurator:
    """Dataset curator for volleyball ball images."""
    
    def __init__(
        self, 
        input_data_dir: str = "volleystat/data/result_detection_yolo",
        output_dataset_dir: str = "volleystat/data/curated_dataset",
        target_count: int = 1000
    ):
        """
        Initialize dataset curator.
        
        Args:
            input_data_dir: Directory with detection results
            output_dataset_dir: Output directory for curated dataset
            target_count: Target number of images for dataset
        """
        self.input_data_dir = Path(input_data_dir)
        self.output_dataset_dir = Path(output_dataset_dir)
        self.target_count = target_count
        
        # Create output directories
        self.output_dataset_dir.mkdir(parents=True, exist_ok=True)
        (self.output_dataset_dir / "images").mkdir(exist_ok=True)
        (self.output_dataset_dir / "labels").mkdir(exist_ok=True)
        
        # Load available images
        self.available_images = self._discover_images()
        self.current_index = 0
        
        # Load existing dataset info
        self.dataset_info_file = self.output_dataset_dir / "dataset_info.json"
        self.accepted_images = self._load_dataset_info()
        
        print(f"🖼️  Found {len(self.available_images)} images for curation")
        print(f"📁 Output dataset directory: {self.output_dataset_dir}")
        print(f"✅ Already accepted: {len(self.accepted_images)} images")
        print(f"🎯 Target: {self.target_count} images")
    
    def _discover_images(self) -> List[Dict[str, Any]]:
        """Discover all available images from detection results."""
        images = []
        
        if not self.input_data_dir.exists():
            print(f"⚠️  Input directory not found: {self.input_data_dir}")
            return images
        
        # Find all video processing directories
        video_dirs = [d for d in self.input_data_dir.iterdir() if d.is_dir() and d.name.startswith("video_")]
        
        for video_dir in video_dirs:
            # Load annotations
            annotations_file = video_dir / "annotations.json"
            if not annotations_file.exists():
                continue
            
            try:
                with open(annotations_file, 'r', encoding='utf-8') as f:
                    annotations = json.load(f)
                
                images_dir = video_dir / "images"
                if not images_dir.exists():
                    continue
                
                # Process each annotation
                for annotation in annotations:
                    if not annotation.get('annotations'):
                        continue
                    
                    # Get image filename from annotation
                    file_upload = annotation.get('file_upload', '')
                    if not file_upload:
                        continue
                    
                    image_path = images_dir / file_upload
                    if not image_path.exists():
                        continue
                    
                    # Extract bounding boxes from annotation
                    bboxes = []
                    for ann in annotation['annotations']:
                        for result in ann.get('result', []):
                            if result.get('type') == 'rectanglelabels':
                                value = result.get('value', {})
                                bbox = {
                                    'x': value.get('x', 0),
                                    'y': value.get('y', 0),
                                    'width': value.get('width', 0),
                                    'height': value.get('height', 0),
                                    'label': value.get('rectanglelabels', ['Ball'])[0]
                                }
                                bboxes.append(bbox)
                    
                    if bboxes:
                        image_info = {
                            'id': str(uuid.uuid4()),
                            'image_path': str(image_path),
                            'video_dir': str(video_dir),
                            'filename': file_upload,
                            'bboxes': bboxes,
                            'annotation': annotation
                        }
                        images.append(image_info)
            
            except Exception as e:
                print(f"⚠️  Error processing {video_dir}: {e}")
                continue
        
        return images
    
    def _load_dataset_info(self) -> List[str]:
        """Load information about already accepted images."""
        if not self.dataset_info_file.exists():
            return []
        
        try:
            with open(self.dataset_info_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return data.get('accepted_images', [])
        except:
            return []
    
    def _save_dataset_info(self) -> None:
        """Save dataset information."""
        data = {
            'accepted_images': self.accepted_images,
            'target_count': self.target_count,
            'created_at': datetime.now().isoformat(),
            'total_accepted': len(self.accepted_images)
        }
        
        with open(self.dataset_info_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    def get_current_image(self) -> Optional[Dict[str, Any]]:
        """Get current image for curation."""
        if self.current_index >= len(self.available_images):
            return None
        
        # Skip already accepted images
        while (self.current_index < len(self.available_images) and 
               self.available_images[self.current_index]['id'] in self.accepted_images):
            self.current_index += 1
        
        if self.current_index >= len(self.available_images):
            return None
        
        return self.available_images[self.current_index]
    
    def process_decision(self, image_id: str, action: str) -> Dict[str, Any]:
        """Process curation decision."""
        # Find image by ID
        image_info = None
        for img in self.available_images:
            if img['id'] == image_id:
                image_info = img
                break
        
        if not image_info:
            raise HTTPException(status_code=404, detail="Image not found")
        
        if action == 'accept':
            if image_id not in self.accepted_images:
                # Copy image and create YOLO label
                self._copy_image_to_dataset(image_info)
                self.accepted_images.append(image_id)
                self._save_dataset_info()
        
        # Move to next image
        self.current_index += 1
        
        return {
            'action': action,
            'image_id': image_id,
            'accepted_count': len(self.accepted_images),
            'target_count': self.target_count,
            'progress': len(self.accepted_images) / self.target_count * 100,
            'completed': len(self.accepted_images) >= self.target_count
        }
    
    def _copy_image_to_dataset(self, image_info: Dict[str, Any]) -> None:
        """Copy image to dataset and create YOLO label."""
        # Create unique filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        image_id = image_info['id'][:8]
        filename_base = f"{timestamp}_{image_id}"
        
        # Copy image
        source_path = Path(image_info['image_path'])
        target_image_path = self.output_dataset_dir / "images" / f"{filename_base}.jpg"
        shutil.copy2(source_path, target_image_path)
        
        # Create YOLO label
        target_label_path = self.output_dataset_dir / "labels" / f"{filename_base}.txt"
        self._create_yolo_label(image_info, target_label_path)
    
    def _create_yolo_label(self, image_info: Dict[str, Any], label_path: Path) -> None:
        """Create YOLO format label file."""
        # Load image to get dimensions
        image = cv2.imread(image_info['image_path'])
        if image is None:
            return
        
        height, width = image.shape[:2]
        
        # Convert bboxes to YOLO format
        with open(label_path, 'w') as f:
            for bbox in image_info['bboxes']:
                # Convert percentage to absolute coordinates
                x_abs = (bbox['x'] / 100) * width
                y_abs = (bbox['y'] / 100) * height
                w_abs = (bbox['width'] / 100) * width
                h_abs = (bbox['height'] / 100) * height
                
                # Convert to YOLO format (center_x, center_y, width, height) normalized
                center_x = (x_abs + w_abs / 2) / width
                center_y = (y_abs + h_abs / 2) / height
                norm_width = w_abs / width
                norm_height = h_abs / height
                
                # Class ID (0 for ball)
                class_id = 0
                
                f.write(f"{class_id} {center_x:.6f} {center_y:.6f} {norm_width:.6f} {norm_height:.6f}\n")
    
    def get_image_with_visualization(self, image_info: Dict[str, Any]) -> Dict[str, Any]:
        """Get image with visualization data."""
        image_path = image_info['image_path']
        image = cv2.imread(image_path)
        
        if image is None:
            raise HTTPException(status_code=500, detail="Could not load image")
        
        height, width = image.shape[:2]
        
        # Create visualization
        vis_image = image.copy()
        crops = []
        
        for bbox in image_info['bboxes']:
            # Convert percentage to absolute coordinates
            x_abs = int((bbox['x'] / 100) * width)
            y_abs = int((bbox['y'] / 100) * height)
            w_abs = int((bbox['width'] / 100) * width)
            h_abs = int((bbox['height'] / 100) * height)
            
            # Draw bounding box
            cv2.rectangle(vis_image, (x_abs, y_abs), (x_abs + w_abs, y_abs + h_abs), (0, 255, 0), 2)
            
            # Add label
            label = f"{bbox['label']}"
            cv2.putText(vis_image, label, (x_abs, y_abs - 10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            
            # Create crop with padding
            padding = 20
            crop_x1 = max(0, x_abs - padding)
            crop_y1 = max(0, y_abs - padding)
            crop_x2 = min(width, x_abs + w_abs + padding)
            crop_y2 = min(height, y_abs + h_abs + padding)
            
            crop = image[crop_y1:crop_y2, crop_x1:crop_x2]
            crops.append(crop)
        
        # Convert images to base64
        original_b64 = self._image_to_base64(image)
        visualization_b64 = self._image_to_base64(vis_image)
        crops_b64 = [self._image_to_base64(crop) for crop in crops]
        
        return {
            'id': image_info['id'],
            'filename': image_info['filename'],
            'original_image': original_b64,
            'visualization_image': visualization_b64,
            'crops': crops_b64,
            'bboxes_count': len(image_info['bboxes']),
            'image_size': f"{width}x{height}"
        }
    
    def _image_to_base64(self, image: np.ndarray) -> str:
        """Convert OpenCV image to base64 string."""
        _, buffer = cv2.imencode('.jpg', image)
        image_b64 = base64.b64encode(buffer).decode('utf-8')
        return f"data:image/jpeg;base64,{image_b64}"
    
    def get_stats(self) -> Dict[str, Any]:
        """Get dataset statistics."""
        return {
            'accepted_count': len(self.accepted_images),
            'target_count': self.target_count,
            'progress': len(self.accepted_images) / self.target_count * 100,
            'remaining': self.target_count - len(self.accepted_images),
            'total_available': len(self.available_images),
            'completed': len(self.accepted_images) >= self.target_count
        }


# Initialize curator
curator = DatasetCurator()

# FastAPI app
app = FastAPI(title="Dataset Curator", description="Volleyball Ball Dataset Curation Tool")

# Serve static files
app.mount("/static", StaticFiles(directory="volleystat/scripts/data_curation/static"), name="static")


@app.get("/", response_class=HTMLResponse)
async def get_main_page():
    """Serve main curation page."""
    html_content = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dataset Curator</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 20px;
                background-color: #f5f5f5;
            }
            .container {
                max-width: 1400px;
                margin: 0 auto;
                background: white;
                border-radius: 10px;
                padding: 20px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            .header {
                text-align: center;
                margin-bottom: 30px;
                padding-bottom: 20px;
                border-bottom: 2px solid #eee;
            }
            .progress {
                background: #e0e0e0;
                border-radius: 10px;
                height: 30px;
                margin: 20px 0;
                overflow: hidden;
            }
            .progress-bar {
                background: linear-gradient(90deg, #4CAF50, #45a049);
                height: 100%;
                transition: width 0.3s ease;
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-weight: bold;
            }
            .image-container {
                display: grid;
                grid-template-columns: 1fr 1fr 1fr;
                gap: 20px;
                margin: 30px 0;
            }
            .image-section {
                text-align: center;
            }
            .image-section h3 {
                margin-bottom: 15px;
                color: #333;
            }
            .image-section img {
                max-width: 100%;
                max-height: 400px;
                border: 2px solid #ddd;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }
            .crops-container {
                display: flex;
                flex-direction: column;
                gap: 10px;
            }
            .crop-image {
                max-width: 100%;
                max-height: 200px;
                border: 2px solid #ddd;
                border-radius: 8px;
            }
            .controls {
                display: flex;
                justify-content: center;
                gap: 30px;
                margin: 30px 0;
            }
            .btn {
                padding: 15px 40px;
                font-size: 18px;
                font-weight: bold;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                transition: all 0.3s ease;
                text-transform: uppercase;
            }
            .btn-accept {
                background: #4CAF50;
                color: white;
            }
            .btn-accept:hover {
                background: #45a049;
                transform: translateY(-2px);
            }
            .btn-skip {
                background: #f44336;
                color: white;
            }
            .btn-skip:hover {
                background: #da190b;
                transform: translateY(-2px);
            }
            .info {
                text-align: center;
                margin: 20px 0;
                font-size: 16px;
                color: #666;
            }
            .keyboard-help {
                text-align: center;
                margin: 20px 0;
                font-size: 14px;
                color: #888;
                background: #f9f9f9;
                padding: 10px;
                border-radius: 5px;
            }
            .loading {
                text-align: center;
                font-size: 18px;
                color: #666;
                margin: 50px 0;
            }
            .completed {
                text-align: center;
                font-size: 24px;
                color: #4CAF50;
                margin: 50px 0;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🏐 Volleyball Ball Dataset Curator</h1>
                <div id="stats">
                    <div class="progress">
                        <div class="progress-bar" id="progressBar">Loading...</div>
                    </div>
                </div>
            </div>
            
            <div id="imageContainer" class="image-container" style="display: none;">
                <div class="image-section">
                    <h3>Original Image</h3>
                    <img id="originalImage" alt="Original">
                    <div class="info" id="imageInfo"></div>
                </div>
                
                <div class="image-section">
                    <h3>With Bounding Boxes</h3>
                    <img id="visualizationImage" alt="With Bounding Boxes">
                </div>
                
                <div class="image-section">
                    <h3>Ball Crops</h3>
                    <div id="cropsContainer" class="crops-container"></div>
                </div>
            </div>
            
            <div id="controls" class="controls" style="display: none;">
                <button class="btn btn-accept" onclick="makeDecision('accept')" id="acceptBtn">
                    ✅ Accept (A)
                </button>
                <button class="btn btn-skip" onclick="makeDecision('skip')" id="skipBtn">
                    ❌ Skip (S)
                </button>
            </div>
            
            <div class="keyboard-help">
                <strong>Keyboard shortcuts:</strong> Press 'A' to Accept, 'S' to Skip, 'Space' to Skip
            </div>
            
            <div id="loading" class="loading">Loading...</div>
            <div id="completed" class="completed" style="display: none;">
                🎉 Dataset completed! You have curated 1000 images.
            </div>
        </div>

        <script>
            let currentImageId = null;
            
            // Load initial image
            loadCurrentImage();
            loadStats();
            
            // Keyboard controls
            document.addEventListener('keydown', function(event) {
                if (event.key.toLowerCase() === 'a') {
                    makeDecision('accept');
                } else if (event.key.toLowerCase() === 's' || event.key === ' ') {
                    event.preventDefault();
                    makeDecision('skip');
                }
            });
            
            async function loadStats() {
                try {
                    const response = await fetch('/api/stats');
                    const stats = await response.json();
                    
                    const progressBar = document.getElementById('progressBar');
                    progressBar.style.width = `${stats.progress}%`;
                    progressBar.textContent = `${stats.accepted_count} / ${stats.target_count} (${stats.progress.toFixed(1)}%)`;
                    
                    if (stats.completed) {
                        document.getElementById('imageContainer').style.display = 'none';
                        document.getElementById('controls').style.display = 'none';
                        document.getElementById('loading').style.display = 'none';
                        document.getElementById('completed').style.display = 'block';
                    }
                } catch (error) {
                    console.error('Error loading stats:', error);
                }
            }
            
            async function loadCurrentImage() {
                try {
                    const response = await fetch('/api/current-image');
                    
                    if (response.status === 204) {
                        // No more images
                        document.getElementById('loading').textContent = 'No more images available.';
                        return;
                    }
                    
                    const data = await response.json();
                    currentImageId = data.id;
                    
                    // Update images
                    document.getElementById('originalImage').src = data.original_image;
                    document.getElementById('visualizationImage').src = data.visualization_image;
                    document.getElementById('imageInfo').textContent = 
                        `${data.filename} | ${data.image_size} | ${data.bboxes_count} ball(s)`;
                    
                    // Update crops
                    const cropsContainer = document.getElementById('cropsContainer');
                    cropsContainer.innerHTML = '';
                    data.crops.forEach((crop, index) => {
                        const img = document.createElement('img');
                        img.src = crop;
                        img.className = 'crop-image';
                        img.alt = `Ball crop ${index + 1}`;
                        cropsContainer.appendChild(img);
                    });
                    
                    // Show UI elements
                    document.getElementById('loading').style.display = 'none';
                    document.getElementById('imageContainer').style.display = 'grid';
                    document.getElementById('controls').style.display = 'flex';
                    
                } catch (error) {
                    console.error('Error loading image:', error);
                    document.getElementById('loading').textContent = 'Error loading image.';
                }
            }
            
            async function makeDecision(action) {
                if (!currentImageId) return;
                
                try {
                    // Disable buttons
                    document.getElementById('acceptBtn').disabled = true;
                    document.getElementById('skipBtn').disabled = true;
                    
                    const response = await fetch('/api/decide', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            image_id: currentImageId,
                            action: action
                        })
                    });
                    
                    const result = await response.json();
                    
                    // Update progress
                    await loadStats();
                    
                    if (result.completed) {
                        document.getElementById('imageContainer').style.display = 'none';
                        document.getElementById('controls').style.display = 'none';
                        document.getElementById('completed').style.display = 'block';
                    } else {
                        // Load next image
                        await loadCurrentImage();
                    }
                    
                    // Re-enable buttons
                    document.getElementById('acceptBtn').disabled = false;
                    document.getElementById('skipBtn').disabled = false;
                    
                } catch (error) {
                    console.error('Error making decision:', error);
                    // Re-enable buttons
                    document.getElementById('acceptBtn').disabled = false;
                    document.getElementById('skipBtn').disabled = false;
                }
            }
        </script>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)


@app.get("/api/stats")
async def get_stats():
    """Get dataset statistics."""
    return curator.get_stats()


@app.get("/api/current-image")
async def get_current_image():
    """Get current image for curation."""
    current_image = curator.get_current_image()
    
    if not current_image:
        return JSONResponse(status_code=204, content={})
    
    try:
        visualization_data = curator.get_image_with_visualization(current_image)
        return visualization_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/decide")
async def make_decision(decision: CurationDecision):
    """Process curation decision."""
    try:
        result = curator.process_decision(decision.image_id, decision.action)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    
    print("🚀 Starting Dataset Curator...")
    print("📱 Open http://localhost:8000 in your browser")
    print("🎮 Use keyboard: 'A' to Accept, 'S' to Skip")
    
    uvicorn.run(app, host="0.0.0.0", port=8000) 
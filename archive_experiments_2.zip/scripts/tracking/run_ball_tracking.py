import cv2
import numpy as np
import os
from src.tracking.ball_tracker import BallTracker

# Example: Load detections from a CSV or list (replace with your actual detection loading)
def load_detections(detections_path):
    # Dummy: Replace with actual loading logic
    # Should return list of (frame_idx, x, y)
    import csv
    detections = []
    with open(detections_path, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            frame_idx, x, y = map(int, row)
            detections.append((frame_idx, x, y))
    return detections

def draw_trajectory_on_video(input_video, output_video, trajectory):
    cap = cv2.VideoCapture(input_video)
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    out = cv2.VideoWriter(output_video, fourcc, fps, (width, height))

    # Build a dict: frame_idx -> (x, y)
    traj_dict = {frame: (x, y) for frame, x, y in trajectory}
    points = []
    frame_idx = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if frame_idx in traj_dict:
            x, y = traj_dict[frame_idx]
            points.append((x, y))
        # Draw trajectory so far
        for i in range(1, len(points)):
            cv2.line(frame, points[i-1], points[i], (0, 0, 255), 2)
        # Optionally, draw current ball position
        if frame_idx in traj_dict:
            x, y = traj_dict[frame_idx]
            cv2.circle(frame, (x, y), 8, (0, 255, 0), -1)
        out.write(frame)
        frame_idx += 1
    cap.release()
    out.release()

if __name__ == "__main__":
    # Paths (replace with your actual paths)
    input_video = "assets/images/test_frame_yolo_faces.jpg"  # For demo, use a video file
    output_video = "results/ball_tracking_with_trajectory.mp4"
    detections_path = "results/ball_detections.csv"  # CSV: frame_idx,x,y

    # Load detections
    detections = load_detections(detections_path)

    # Run tracker
    tracker = BallTracker()
    for frame_idx, x, y in detections:
        tracker.update(frame_idx, (x, y))
    trajectory = tracker.get_trajectory()

    # Draw trajectory on video
    draw_trajectory_on_video(input_video, output_video, trajectory)
    print(f"Saved output video with trajectory: {output_video}") 
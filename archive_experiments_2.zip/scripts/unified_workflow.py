#!/usr/bin/env python3
"""
Unified Workflow для Active Contour
Об'єднаний воркфлоу, що використовує модель передбачення параметрів
та систему відстеження покращень
"""

import json
import cv2
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import random
from tqdm import tqdm
import base64
from io import BytesIO
from PIL import Image
import datetime
import pickle
import joblib

# Машинне навчання
from sklearn.ensemble import RandomForestRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

# Оптимізація
from scipy.optimize import minimize
from scipy.stats import qmc

# Scikit-image для активних контурів
from skimage.segmentation import active_contour
from skimage.filters import gaussian as gaussian_filter

# Функція для конвертації в grayscale
def rgb2gray(image):
    if len(image.shape) == 3:
        return np.dot(image[...,:3], [0.2989, 0.5870, 0.1140]) / 255.0
    return image / 255.0


class UnifiedActiveContourWorkflow:
    """Об'єднаний воркфлоу для оптимізації параметрів активних контурів."""
    
    def __init__(self):
        """Ініціалізація об'єднаного воркфлоу."""
        self.session_id = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Створюємо папки для результатів
        base_path = Path(r"C:\Users\illya\Documents\volleyball_analitics")
        self.output_dir = base_path / f"volleystat/data/unified_workflow_{self.session_id}"
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.model_dir = base_path / "volleystat/data/parameter_space_model"
        
        # Ініціалізуємо компоненти
        self.models = {}
        self.scaler_X = None
        self.scaler_y = None
        self.training_data = []
        self.improvement_history = []
        self.best_intersection_ratio = 0.0
        
        # Діапазони параметрів
        self.parameter_ranges = {
            'alpha': np.logspace(-4, 0, 20),  # 0.0001 to 1.0
            'beta': np.logspace(-1, 2, 15),   # 0.1 to 100
            'gamma': np.logspace(-3, -1, 10)  # 0.001 to 0.1
        }
        
        print(f"📁 Результати будуть збережені в: {self.output_dir}")
        print(f"🤖 Модель буде збережена в: {self.model_dir}")
    
    def decode_base64_image(self, base64_string: str) -> np.ndarray:
        """Декодує base64 зображення в numpy array."""
        try:
            if ',' in base64_string:
                base64_string = base64_string.split(',')[1]
            
            image_bytes = base64.b64decode(base64_string)
            pil_image = Image.open(BytesIO(image_bytes))
            image_array = np.array(pil_image)
            
            if len(image_array.shape) == 3:
                image_array = cv2.cvtColor(image_array, cv2.COLOR_RGB2BGR)
            
            return image_array
            
        except Exception as e:
            print(f"❌ Помилка декодування зображення: {e}")
            return None
    
    def load_sample_data(self, json_path: Path, num_samples: int = 5) -> List[Dict]:
        """Завантажує зразки для роботи."""
        print(f"📂 Завантаження зразків з: {json_path}")
        
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Фільтруємо елементи з анотаціями volleyball ball
        annotated_data = []
        for item in data:
            if item.get('annotations') and len(item['annotations']) > 0:
                for annotation in item['annotations']:
                    if annotation.get('result'):
                        for result in annotation['result']:
                            if (result.get('value', {}).get('rectanglelabels') and 
                                'Volleyball Ball' in result['value']['rectanglelabels']):
                                annotated_data.append(item)
                                break
        
        # Вибираємо випадкові зразки
        random.seed(42)
        selected_data = random.sample(annotated_data, min(num_samples, len(annotated_data)))
        
        print(f"✅ Вибрано {len(selected_data)} зразків")
        return selected_data
    
    def extract_image_and_bbox(self, item: Dict) -> Tuple[str, np.ndarray, Tuple[int, int, int, int]]:
        """Витягує зображення та bbox з Label Studio."""
        filename = item.get('file_upload', 'unknown')
        
        # Отримуємо зображення
        image = None
        if 'data' in item and 'image' in item['data']:
            image_data = item['data']['image']
            image = self.decode_base64_image(image_data)
        
        # Отримуємо bbox
        for annotation in item['annotations']:
            if annotation.get('result'):
                for result in annotation['result']:
                    if (result.get('value', {}).get('rectanglelabels') and 
                        'Volleyball Ball' in result['value']['rectanglelabels']):
                        
                        value = result['value']
                        original_width = result['original_width']
                        original_height = result['original_height']
                        
                        x_percent = value['x']
                        y_percent = value['y']
                        width_percent = value['width']
                        height_percent = value['height']
                        
                        x1 = int((x_percent / 100.0) * original_width)
                        y1 = int((y_percent / 100.0) * original_height)
                        x2 = int(((x_percent + width_percent) / 100.0) * original_width)
                        y2 = int(((y_percent + height_percent) / 100.0) * original_height)
                        
                        return filename, image, (x1, y1, x2, y2)
        
        return filename, image, None
    
    def create_ball_crop(self, image: np.ndarray, bbox: Tuple[int, int, int, int], 
                        padding_percent: float = 0.5) -> Tuple[np.ndarray, Tuple[int, int, int, int]]:
        """Створює кроп м'яча з додатковим простором."""
        x1, y1, x2, y2 = bbox
        
        width = x2 - x1
        height = y2 - y1
        
        padding_x = int(width * padding_percent)
        padding_y = int(height * padding_percent)
        
        crop_x1 = max(0, x1 - padding_x)
        crop_y1 = max(0, y1 - padding_y)
        crop_x2 = min(image.shape[1], x2 + padding_x)
        crop_y2 = min(image.shape[0], y2 + padding_y)
        
        crop = image[crop_y1:crop_y2, crop_x1:crop_x2]
        new_bbox = (x1 - crop_x1, y1 - crop_y1, x2 - crop_x1, y2 - crop_y1)
        
        return crop, new_bbox
    
    def extract_image_features(self, crop: np.ndarray, bbox: Tuple[int, int, int, int]) -> np.ndarray:
        """Витягує ознаки зображення для моделі."""
        features = []
        
        # Конвертуємо в grayscale
        if len(crop.shape) == 3:
            gray = rgb2gray(crop)
        else:
            gray = crop / 255.0 if crop.max() > 1 else crop
        
        # 1. Розмірні характеристики
        h, w = gray.shape
        features.extend([w, h, w*h])
        
        # 2. Характеристики bbox
        x1, y1, x2, y2 = bbox
        bbox_w, bbox_h = x2 - x1, y2 - y1
        features.extend([bbox_w, bbox_h, bbox_w * bbox_h])
        
        # 3. Статистичні характеристики зображення
        features.extend([
            np.mean(gray),
            np.std(gray),
            np.min(gray),
            np.max(gray),
        ])
        
        # 4. Градієнтні характеристики
        grad_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        grad_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        gradient_magnitude = np.sqrt(grad_x**2 + grad_y**2)
        
        features.extend([
            np.mean(gradient_magnitude),
            np.std(gradient_magnitude),
            np.max(gradient_magnitude)
        ])
        
        # 5. Текстурні характеристики
        kernel = np.ones((5,5), np.float32) / 25
        local_mean = cv2.filter2D(gray, -1, kernel)
        local_variance = cv2.filter2D(gray**2, -1, kernel) - local_mean**2
        
        features.extend([
            np.mean(local_variance),
            np.std(local_variance)
        ])
        
        return np.array(features, dtype=np.float32)
    
    def create_initial_contour(self, bbox: Tuple[int, int, int, int], 
                              contour_type: str = "circle", num_points: int = 50) -> np.ndarray:
        """Створює початковий контур."""
        x1, y1, x2, y2 = bbox
        center_x = (x1 + x2) / 2
        center_y = (y1 + y2) / 2
        width = x2 - x1
        height = y2 - y1
        
        # Круговий контур для м'яча
        radius = min(width, height) / 2 * 0.8
        angles = np.linspace(0, 2 * np.pi, num_points)
        x = center_x + radius * np.cos(angles)
        y = center_y + radius * np.sin(angles)
        
        return np.column_stack([x, y])
    
    def evaluate_parameters(self, crop: np.ndarray, bbox: Tuple[int, int, int, int],
                           alpha: float, beta: float, gamma: float) -> float:
        """Оцінює якість параметрів для заданого зображення."""
        try:
            # Створюємо початковий контур
            initial_contour = self.create_initial_contour(bbox, "circle")
            
            # Конвертуємо в grayscale
            if len(crop.shape) == 3:
                gray = rgb2gray(crop)
            else:
                gray = crop / 255.0 if crop.max() > 1 else crop
            
            # Згладжуємо зображення
            smoothed = gaussian_filter(gray, sigma=1.0, preserve_range=False)
            
            # Застосовуємо активні контури
            final_contour = active_contour(
                smoothed,
                initial_contour,
                alpha=alpha,
                beta=beta,
                gamma=gamma,
                boundary_condition='periodic'
            )
            
            # Перевіряємо валідність
            if len(final_contour) < 3:
                return 0.0
                
            # Обмежуємо контур межами зображення
            h, w = smoothed.shape
            final_contour[:, 0] = np.clip(final_contour[:, 0], 0, w-1)
            final_contour[:, 1] = np.clip(final_contour[:, 1], 0, h-1)
            
            # Обчислюємо якість сегментації
            quality_score = self.calculate_quality_score(initial_contour, final_contour, bbox, crop.shape[:2])
            
            return quality_score
            
        except Exception as e:
            print(f"⚠️ Помилка оцінки параметрів (α={alpha}, β={beta}, γ={gamma}): {e}")
            return 0.0
    
    def calculate_quality_score(self, initial_contour: np.ndarray, final_contour: np.ndarray, 
                               bbox: Tuple[int, int, int, int], crop_shape: Tuple[int, int]) -> float:
        """Обчислює якість сегментації з покращеною метрикою."""
        try:
            # Створюємо маски
            initial_mask = np.zeros(crop_shape, dtype=np.uint8)
            initial_contour_int = initial_contour.astype(np.int32)
            cv2.fillPoly(initial_mask, [initial_contour_int], 255)
            initial_area = np.sum(initial_mask > 0)
            
            final_mask = np.zeros(crop_shape, dtype=np.uint8)
            final_contour_int = final_contour.astype(np.int32)
            cv2.fillPoly(final_mask, [final_contour_int], 255)
            final_area = np.sum(final_mask > 0)
            
            # Площа баундінг боксу
            x1, y1, x2, y2 = bbox
            bbox_area = (x2 - x1) * (y2 - y1)
            
            # ПОКРАЩЕНА МЕТРИКА ЯКОСТІ:
            
            # 1. IoU з баундінг боксом (основний критерій!)
            bbox_mask = np.zeros(crop_shape, dtype=np.uint8)
            cv2.rectangle(bbox_mask, (x1, y1), (x2, y2), 255, -1)
            
            intersection = np.logical_and(final_mask > 0, bbox_mask > 0)
            union = np.logical_or(final_mask > 0, bbox_mask > 0)
            
            intersection_area = np.sum(intersection)
            union_area = np.sum(union)
            
            if union_area > 0:
                iou_with_bbox = intersection_area / union_area
            else:
                iou_with_bbox = 0.0
            
            # 2. Штраф за занадто малі маски
            if bbox_area > 0:
                size_ratio = final_area / bbox_area
                if size_ratio < 0.1:  # Якщо маска менше 10% від bbox - великий штраф
                    size_penalty = size_ratio / 0.1  # 0.0 - 1.0
                elif size_ratio < 0.3:  # Якщо менше 30% - невеликий штраф
                    size_penalty = 0.5 + (size_ratio - 0.1) / 0.2 * 0.5  # 0.5 - 1.0
                else:
                    size_penalty = 1.0  # Без штрафу
            else:
                size_penalty = 0.0
            
            # 3. Збільшення площі (бонус за розширення)
            if initial_area > 0:
                area_growth = final_area / initial_area
                growth_bonus = min(area_growth, 3.0) / 3.0  # Максимум 3x збільшення
            else:
                growth_bonus = 0.0
            
            # 4. Компактність (для круглого м'яча)
            perimeter = cv2.arcLength(final_contour_int, True)
            if perimeter > 0 and final_area > 0:
                compactness = 4 * np.pi * final_area / (perimeter * perimeter)
                compactness = min(compactness, 1.0)
            else:
                compactness = 0.0
            
            # КОМБІНОВАНИЙ СКОР (IoU - найважливіший!)
            quality_score = (
                iou_with_bbox * 0.6 +          # 60% - IoU з bbox (основне!)
                size_penalty * 0.2 +           # 20% - штраф за малий розмір
                growth_bonus * 0.1 +           # 10% - бонус за збільшення
                compactness * 0.1              # 10% - компактність
            )
            
            return quality_score
            
        except Exception as e:
            print(f"⚠️ Помилка обчислення якості: {e}")
            return 0.0
    
    def calculate_intersection_ratio(self, contour: np.ndarray, bbox: Tuple[int, int, int, int], 
                                   crop_shape: Tuple[int, int]) -> float:
        """Обчислює коефіцієнт перетину між контуром та баундінг боксом."""
        try:
            # Створюємо маску контуру
            contour_mask = np.zeros(crop_shape, dtype=np.uint8)
            contour_int = contour.astype(np.int32)
            cv2.fillPoly(contour_mask, [contour_int], 255)
            
            # Створюємо маску баундінг боксу
            x1, y1, x2, y2 = bbox
            bbox_mask = np.zeros(crop_shape, dtype=np.uint8)
            cv2.rectangle(bbox_mask, (x1, y1), (x2, y2), 255, -1)
            
            # Обчислюємо перетин та об'єднання
            intersection = np.logical_and(contour_mask > 0, bbox_mask > 0)
            union = np.logical_or(contour_mask > 0, bbox_mask > 0)
            
            intersection_area = np.sum(intersection)
            union_area = np.sum(union)
            
            # IoU (Intersection over Union)
            if union_area > 0:
                iou = intersection_area / union_area
            else:
                iou = 0.0
            
            return float(iou)
            
        except Exception as e:
            print(f"⚠️ Помилка обчислення перетину: {e}")
            return 0.0
    
    # ЕТАП 1: ЗБІР НАВЧАЛЬНИХ ДАНИХ
    def collect_training_data(self, json_path: Path, num_samples: int = 3, 
                             samples_per_image: int = 50):
        """Збирає навчальні дані для моделі."""
        print("\n🔄 ЕТАП 1: Збір навчальних даних для моделі...")
        
        # Завантажуємо зразки
        sample_data = self.load_sample_data(json_path, num_samples)
        
        # Створюємо комбінації параметрів для тестування
        sampler = qmc.LatinHypercube(d=3, seed=42)
        param_samples = sampler.random(n=samples_per_image)
        
        # Масштабуємо до наших діапазонів (в log-space)
        alpha_log_min, alpha_log_max = np.log10(self.parameter_ranges['alpha'].min()), np.log10(self.parameter_ranges['alpha'].max())
        beta_log_min, beta_log_max = np.log10(self.parameter_ranges['beta'].min()), np.log10(self.parameter_ranges['beta'].max())
        gamma_log_min, gamma_log_max = np.log10(self.parameter_ranges['gamma'].min()), np.log10(self.parameter_ranges['gamma'].max())
        
        alphas = 10 ** (param_samples[:, 0] * (alpha_log_max - alpha_log_min) + alpha_log_min)
        betas = 10 ** (param_samples[:, 1] * (beta_log_max - beta_log_min) + beta_log_min)
        gammas = 10 ** (param_samples[:, 2] * (gamma_log_max - gamma_log_min) + gamma_log_min)
        
        print(f"📊 Тестуватимемо {len(alphas)} комбінацій параметрів на {len(sample_data)} зображеннях")
        
        # Збираємо дані
        training_data = []
        
        for item_idx, item in enumerate(tqdm(sample_data, desc="Збір навчальних даних")):
            filename, image, bbox = self.extract_image_and_bbox(item)
            
            if image is None or bbox is None:
                continue
            
            # Створюємо кроп
            crop, crop_bbox = self.create_ball_crop(image, bbox)
            
            # Витягуємо ознаки зображення
            image_features = self.extract_image_features(crop, crop_bbox)
            
            print(f"\n📷 Зображення {item_idx+1}/{len(sample_data)}: {filename}")
            
            # Тестуємо всі комбінації параметрів на цьому зображенні
            for param_idx in tqdm(range(len(alphas)), desc=f"Тестування параметрів", leave=False):
                alpha = alphas[param_idx]
                beta = betas[param_idx]
                gamma = gammas[param_idx]
                
                # Оцінюємо якість цих параметрів
                quality_score = self.evaluate_parameters(crop, crop_bbox, alpha, beta, gamma)
                
                # Зберігаємо навчальний приклад
                training_example = {
                    'image_features': image_features,
                    'parameters': np.array([alpha, beta, gamma]),
                    'quality_score': quality_score,
                    'filename': filename,
                    'item_idx': item_idx
                }
                
                training_data.append(training_example)
        
        self.training_data = training_data
        print(f"\n✅ Зібрано {len(training_data)} навчальних прикладів")
        
        # Зберігаємо дані
        self.model_dir.mkdir(parents=True, exist_ok=True)
        with open(self.model_dir / "training_data.pkl", 'wb') as f:
            pickle.dump(training_data, f)
        
        print(f"💾 Навчальні дані збережено в: {self.model_dir / 'training_data.pkl'}")
    
    # ЕТАП 2: НАВЧАННЯ МОДЕЛІ
    def train_models(self):
        """Навчає моделі на зібраних даних."""
        print("\n🎓 ЕТАП 2: Навчання моделей...")
        
        if not self.training_data:
            # Спробуємо завантажити збережені дані
            training_data_path = self.model_dir / "training_data.pkl"
            if training_data_path.exists():
                with open(training_data_path, 'rb') as f:
                    self.training_data = pickle.load(f)
                print(f"📂 Завантажено {len(self.training_data)} навчальних прикладів")
            else:
                print("❌ Немає навчальних даних. Спочатку запустіть collect_training_data()")
                return
        
        # Підготовка даних
        X_features = []
        y_scores = []
        
        for example in self.training_data:
            # Комбінуємо ознаки зображення та параметри
            combined_features = np.concatenate([
                example['image_features'],
                example['parameters']
            ])
            X_features.append(combined_features)
            y_scores.append(example['quality_score'])
        
        X_features = np.array(X_features)
        y_scores = np.array(y_scores)
        
        print(f"📊 Розмір навчальних даних: {X_features.shape}")
        print(f"📈 Діапазон якості: {y_scores.min():.4f} - {y_scores.max():.4f}")
        
        # Нормалізація
        self.scaler_X = StandardScaler()
        self.scaler_y = StandardScaler()
        
        X_scaled = self.scaler_X.fit_transform(X_features)
        y_scaled = self.scaler_y.fit_transform(y_scores.reshape(-1, 1)).ravel()
        
        # Розділення на навчальну та тестову вибірки
        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled, y_scaled, test_size=0.2, random_state=42
        )
        
        # Ініціалізуємо моделі
        self.models = {
            'random_forest': RandomForestRegressor(n_estimators=100, random_state=42),
            'gaussian_process': GaussianProcessRegressor(
                kernel=ConstantKernel(1.0) * RBF(1.0),
                random_state=42,
                alpha=1e-6
            )
        }
        
        # Навчання моделей
        trained_models = {}
        for model_name, model in self.models.items():
            print(f"\n🔄 Навчання {model_name}...")
            
            model.fit(X_train, y_train)
            
            # Оцінка на тестовій вибірці
            y_pred = model.predict(X_test)
            mse = mean_squared_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)
            
            print(f"   📊 MSE: {mse:.4f}")
            print(f"   📊 R²:  {r2:.4f}")
            
            trained_models[model_name] = model
        
        self.models = trained_models
        
        # Зберігаємо навчені моделі
        for model_name, model in self.models.items():
            joblib.dump(model, self.model_dir / f"{model_name}_model.pkl")
        
        joblib.dump(self.scaler_X, self.model_dir / "scaler_X.pkl")
        joblib.dump(self.scaler_y, self.model_dir / "scaler_y.pkl")
        
        print(f"\n💾 Навчені моделі збережено в: {self.model_dir}")
    
    # ЕТАП 3: ЗАВАНТАЖЕННЯ НАВЧЕНОЇ МОДЕЛІ
    def load_trained_model(self, model_name: str = 'gaussian_process'):
        """Завантажує навчену модель."""
        print(f"\n📂 ЕТАП 3: Завантаження навченої моделі ({model_name})...")
        
        try:
            model_path = self.model_dir / f"{model_name}_model.pkl"
            scaler_X_path = self.model_dir / "scaler_X.pkl"
            scaler_y_path = self.model_dir / "scaler_y.pkl"
            
            if not all([model_path.exists(), scaler_X_path.exists(), scaler_y_path.exists()]):
                print("❌ Навчена модель не знайдена. Спочатку запустіть train_models()")
                return False
            
            self.models[model_name] = joblib.load(model_path)
            self.scaler_X = joblib.load(scaler_X_path)
            self.scaler_y = joblib.load(scaler_y_path)
            
            print(f"✅ Модель {model_name} успішно завантажена")
            return True
            
        except Exception as e:
            print(f"❌ Помилка завантаження моделі: {e}")
            return False
    
    # ЕТАП 4: ПЕРЕДБАЧЕННЯ ПАРАМЕТРІВ ТА ВІДСТЕЖЕННЯ ПОКРАЩЕНЬ
    def predict_and_track_improvements(self, json_path: Path, num_samples: int = 1,
                                     model_name: str = 'gaussian_process'):
        """Передбачає параметри та відстежує покращення."""
        print(f"\n🎯 ЕТАП 4: Передбачення параметрів та відстеження покращень...")
        
        # Завантажуємо зразки
        sample_data = self.load_sample_data(json_path, num_samples)
        
        if not sample_data:
            print("❌ Не знайдено даних для тестування")
            return
        
        # Обробляємо кожен зразок
        for sample_idx, item in enumerate(sample_data):
            filename, image, bbox = self.extract_image_and_bbox(item)
            
            if image is None or bbox is None:
                continue
            
            print(f"\n📷 Зображення {sample_idx+1}/{len(sample_data)}: {filename}")
            
            # Створюємо кроп
            crop, crop_bbox = self.create_ball_crop(image, bbox)
            print(f"✂️ Розмір кропу: {crop.shape}")
            
            # Передбачаємо оптимальні параметри
            optimal_params = self.predict_optimal_parameters(crop, crop_bbox, model_name)
            
            if optimal_params:
                alpha, beta, gamma = optimal_params
                
                # Застосовуємо передбачені параметри
                final_contour = self.apply_active_contour(crop, crop_bbox, alpha, beta, gamma)
                
                # Обчислюємо перетин
                intersection_ratio = self.calculate_intersection_ratio(final_contour, crop_bbox, crop.shape[:2])
                
                print(f"🎯 Передбачені параметри: α={alpha:.4f}, β={beta:.2f}, γ={gamma:.4f}")
                print(f"📊 IoU з bbox: {intersection_ratio:.4f}")
                
                # Зберігаємо візуалізацію
                self.save_prediction_visualization(
                    crop, crop_bbox, final_contour, 
                    {'alpha': alpha, 'beta': beta, 'gamma': gamma},
                    intersection_ratio, filename, sample_idx
                )
    
    def predict_optimal_parameters(self, crop: np.ndarray, bbox: Tuple[int, int, int, int],
                                  model_name: str = 'gaussian_process') -> Optional[Tuple[float, float, float]]:
        """Передбачає оптимальні параметри для заданого зображення."""
        if model_name not in self.models:
            print(f"❌ Модель {model_name} не завантажена")
            return None
        
        # Витягуємо ознаки зображення
        image_features = self.extract_image_features(crop, bbox)
        
        # Функція для оптимізації
        def objective(params):
            alpha, beta, gamma = params
            
            # Комбінуємо ознаки зображення та параметри
            combined_features = np.concatenate([image_features, params])
            combined_features_scaled = self.scaler_X.transform([combined_features])
            
            # Передбачаємо якість
            predicted_quality_scaled = self.models[model_name].predict(combined_features_scaled)[0]
            predicted_quality = self.scaler_y.inverse_transform([[predicted_quality_scaled]])[0][0]
            
            # Повертаємо негативну якість для мінімізації
            return -predicted_quality
        
        # Початкове наближення
        initial_guess = [0.1, 1.0, 0.01]
        
        # Межі параметрів
        bounds = [
            (self.parameter_ranges['alpha'].min(), self.parameter_ranges['alpha'].max()),
            (self.parameter_ranges['beta'].min(), self.parameter_ranges['beta'].max()),
            (self.parameter_ranges['gamma'].min(), self.parameter_ranges['gamma'].max())
        ]
        
        # Оптимізація
        result = minimize(objective, initial_guess, bounds=bounds, method='L-BFGS-B')
        
        if result.success:
            optimal_alpha, optimal_beta, optimal_gamma = result.x
            return optimal_alpha, optimal_beta, optimal_gamma
        else:
            print(f"⚠️ Оптимізація не вдалася: {result.message}")
            return None
    
    def apply_active_contour(self, crop: np.ndarray, bbox: Tuple[int, int, int, int],
                           alpha: float, beta: float, gamma: float) -> np.ndarray:
        """Застосовує активні контури з заданими параметрами."""
        try:
            # Створюємо початковий контур
            initial_contour = self.create_initial_contour(bbox, "circle")
            
            # Конвертуємо в grayscale
            if len(crop.shape) == 3:
                gray = rgb2gray(crop)
            else:
                gray = crop / 255.0 if crop.max() > 1 else crop
            
            # Згладжуємо зображення
            smoothed = gaussian_filter(gray, sigma=1.0, preserve_range=False)
            
            # Застосовуємо активні контури
            final_contour = active_contour(
                smoothed,
                initial_contour,
                alpha=alpha,
                beta=beta,
                gamma=gamma,
                boundary_condition='periodic'
            )
            
            # Перевіряємо валідність
            if len(final_contour) < 3:
                return initial_contour
                
            # Обмежуємо контур межами зображення
            h, w = smoothed.shape
            final_contour[:, 0] = np.clip(final_contour[:, 0], 0, w-1)
            final_contour[:, 1] = np.clip(final_contour[:, 1], 0, h-1)
            
            return final_contour
            
        except Exception as e:
            print(f"⚠️ Помилка в active_contour (α={alpha}, β={beta}, γ={gamma}): {e}")
            return self.create_initial_contour(bbox, "circle")
    
    def save_prediction_visualization(self, crop: np.ndarray, bbox: Tuple[int, int, int, int],
                                    contour: np.ndarray, parameters: Dict, 
                                    intersection_ratio: float, filename: str, sample_idx: int):
        """Зберігає візуалізацію передбачення з параметрами."""
        
        # Створюємо візуалізацію
        fig, ax = plt.subplots(1, 1, figsize=(12, 10))
        
        # Копіюємо кроп для візуалізації
        crop_viz = crop.copy()
        
        # Малюємо синій баундінг бокс
        x1, y1, x2, y2 = bbox
        pts_bbox = np.array([[x1, y1], [x2, y1], [x2, y2], [x1, y2]], np.int32)
        crop_viz = cv2.polylines(crop_viz, [pts_bbox], True, (255, 0, 0), 3)  # Синій
        
        # Малюємо зелений контур
        if contour is not None and len(contour) > 0:
            contour_int = contour.astype(np.int32)
            crop_viz = cv2.polylines(crop_viz, [contour_int], True, (0, 255, 0), 3)  # Зелений
        
        # Показуємо зображення
        ax.imshow(crop_viz[..., ::-1])  # BGR to RGB
        ax.axis('off')
        
        # Додаємо заголовок з параметрами
        title = f"🤖 Передбачені параметри моделлю | IoU: {intersection_ratio:.4f}\n"
        title += f"α = {parameters['alpha']:.4f}, β = {parameters['beta']:.2f}, γ = {parameters['gamma']:.4f}\n"
        title += f"Файл: {filename}"
        
        ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
        
        # Додаємо легенду
        legend_text = "🔵 Синій = Оригінальний баундінг бокс\n🟢 Зелений = Передбачена маска Active Contour\n🤖 Параметри передбачені моделлю машинного навчання"
        ax.text(0.02, 0.98, legend_text, transform=ax.transAxes, 
                fontsize=11, verticalalignment='top',
                bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.9))
        
        plt.tight_layout()
        
        # Зберігаємо
        output_filename = f"prediction_{sample_idx:03d}_{Path(filename).stem}_iou_{intersection_ratio:.4f}.png"
        output_path = self.output_dir / output_filename
        plt.savefig(output_path, dpi=200, bbox_inches='tight')
        plt.close()
        
        print(f"💾 Збережено передбачення: {output_path}")
    
    # ГОЛОВНИЙ ВОРКФЛОУ
    def run_full_workflow(self, json_path: Path, 
                         train_samples: int = 3, 
                         test_samples: int = 1,
                         samples_per_image: int = 50,
                         model_name: str = 'gaussian_process',
                         skip_training: bool = False):
        """
        Запускає повний воркфлоу: збір даних → навчання → передбачення → відстеження.
        
        Args:
            json_path: Шлях до Label Studio JSON
            train_samples: Кількість зображень для навчання
            test_samples: Кількість зображень для тестування
            samples_per_image: Кількість комбінацій параметрів на зображення
            model_name: Назва моделі для використання
            skip_training: Пропустити навчання (використати існуючу модель)
        """
        print("🚀 ЗАПУСК ПОВНОГО ВОРКФЛОУ ОПТИМІЗАЦІЇ ПАРАМЕТРІВ")
        print("=" * 60)
        
        if not skip_training:
            # Етап 1: Збір навчальних даних
            self.collect_training_data(json_path, train_samples, samples_per_image)
            
            # Етап 2: Навчання моделі
            self.train_models()
        
        # Етап 3: Завантаження навченої моделі
        if self.load_trained_model(model_name):
            
            # Етап 4: Передбачення та відстеження
            self.predict_and_track_improvements(json_path, test_samples, model_name)
            
            print("\n✅ ПОВНИЙ ВОРКФЛОУ ЗАВЕРШЕНО!")
            print(f"📁 Результати збережено в: {self.output_dir}")
            print(f"🤖 Модель збережено в: {self.model_dir}")
        else:
            print("❌ Не вдалося завантажити модель")


def main():
    """Головна функція для запуску об'єднаного воркфлоу."""
    print("🎯 Unified Active Contour Workflow")
    print("🤖 Модель передбачення параметрів + Відстеження покращень")
    
    # Шлях до розмітки Label Studio
    json_path = Path(r"C:\Users\illya\Documents\volleyball_analitics\volleystat\data\label_studio_chunks_with_images\volleyball_ball_detection_chunk_001_of_046.json")
    
    if not json_path.exists():
        print(f"❌ Файл розмітки не знайдено: {json_path}")
        return
    
    # Створюємо об'єднаний воркфлоу
    workflow = UnifiedActiveContourWorkflow()
    
    # Запускаємо повний воркфлоу
    workflow.run_full_workflow(
        json_path=json_path,
        train_samples=2,           # Кількість зображень для навчання
        test_samples=1,            # Кількість зображень для тестування
        samples_per_image=30,      # Комбінацій параметрів на зображення
        model_name='gaussian_process',  # Модель для використання
        skip_training=False        # False = повне навчання, True = використати існуючу модель
    )


if __name__ == "__main__":
    main() 